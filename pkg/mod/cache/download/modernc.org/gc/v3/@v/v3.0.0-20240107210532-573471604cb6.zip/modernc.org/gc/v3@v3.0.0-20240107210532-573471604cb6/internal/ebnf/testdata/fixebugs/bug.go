package p

func f() {
	for ; ; d = (e) {
	}
}
