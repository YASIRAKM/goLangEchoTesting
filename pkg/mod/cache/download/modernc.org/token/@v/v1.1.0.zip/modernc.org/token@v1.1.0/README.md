# token

Package token is a variant of the stdlib package token with types FileSet and Token removed

Installation

    $ go get [-u] modernc.org/token

Documentation: [godoc.org/modernc.org/token](http://godoc.org/modernc.org/token)
